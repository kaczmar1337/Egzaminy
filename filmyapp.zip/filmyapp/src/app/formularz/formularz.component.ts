import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgForOf } from '@angular/common';

@Component({
  selector: 'app-formularz',
  standalone: true,
  imports: [FormsModule, NgForOf],
  templateUrl: './formularz.component.html',
  styleUrls: ['./formularz.component.css'],
})
export class FormularzComponent {
  filmTitle: string = '';
  category: string = '';
  categories: { value: string, label: string }[] = [
    { value: '', label: 'Pusta' },
    { value: '1', label: 'Kategoria o wartości 1' },
    { value: '2', label: 'Kategoria o wartości 2' },
    { value: '3', label: 'Kategoria o wartości 3' },
  ];
  output: string[] = [];

  onSubmit() {
    console.log('onSubmit działa!');
    if (this.filmTitle && this.category) {
      console.log(`Tytuł: ${this.filmTitle}, Kategoria: ${this.category}`);
      this.output.push(`Tytuł: ${this.filmTitle}, Kategoria: ${this.category}`);
      this.filmTitle = '';
      this.category = '';
    } else {
      alert('Proszę wypełnić wszystkie pola formularza.');
    }
  }
}

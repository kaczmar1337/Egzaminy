import { Component } from '@angular/core';
import { FormularzComponent } from './formularz/formularz.component';

@Component({
  selector: 'app-root',
  standalone: true,
  template: '<app-formularz></app-formularz>',
  imports: [FormularzComponent],
})
export class AppComponent {}

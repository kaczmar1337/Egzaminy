import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, CommonModule],
  template: `
    <div class="container mt-5">
      <h2>Liczba kursów: {{ kursy.length }}</h2>
      <ol>
        <li *ngFor="let kurs of kursy">{{ kurs }}</li>
      </ol>

      <form (ngSubmit)="zapiszDoKursu()">
        <div class="mb-3">
          <label for="imieNazwisko" class="form-label">Imię i nazwisko:</label>
          <input [(ngModel)]="imieNazwisko" name="imieNazwisko" id="imieNazwisko" class="form-control" required>
        </div>

        <div class="mb-3">
          <label for="numerKursu" class="form-label">Numer kursu:</label>
          <input type="number" [(ngModel)]="numerKursu" name="numerKursu" id="numerKursu" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Zapisz do kursu</button>
      </form>

      <div *ngIf="komunikat" class="alert alert-info mt-3">
        {{ komunikat }}
      </div>
    </div>
  `,
  styles: []
})
export class AppComponent {
  kursy: string[] = ['Programowanie w C#', 'Angular dla początkujących', 'Kurs Django'];
  imieNazwisko: string = '';
  numerKursu: number | null = null;
  komunikat: string = '';

  zapiszDoKursu() {
    if (this.numerKursu !== null && this.numerKursu > 0 && this.numerKursu <= this.kursy.length) {
      this.komunikat = `${this.imieNazwisko} zapisany na kurs: ${this.kursy[this.numerKursu - 1]}`;
      console.log(this.komunikat);
    } else {
      this.komunikat = 'Nieprawidłowy numer kursu';
      console.warn(this.komunikat);
    }
  }
}
import { Component } from '@angular/core';

@Component({
  selector: 'app-kursy-form',
  templateUrl: './kursy-form.component.html',
  styleUrls: ['./kursy-form.component.css']
})
export class KursyFormComponent {
  kursy: string[] = ['Programowanie w C#', 'Angular dla początkujących', 'Kurs Django'];
  liczbaKursow: number = this.kursy.length;

  imieNazwisko: string = '';
  numerKursu: number | null = null;
  komunikat: string = '';

  zapiszDoKursu() {
    if (this.numerKursu !== null && this.numerKursu > 0 && this.numerKursu <= this.liczbaKursow) {
      console.log(`${this.imieNazwisko} zapisany na kurs: ${this.kursy[this.numerKursu - 1]}`);
      this.komunikat = `${this.imieNazwisko} zapisany na kurs: ${this.kursy[this.numerKursu - 1]}`;
    } else {
      this.komunikat = 'Nieprawidłowy numer kursu';
    }
  }
}
